<?php

$host = "localhost";  
$username = "root";  
$password = "";  
$database = "contact_db";  

$conn = mysqli_connect($host, $username, $password, $database);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  
    $name = mysqli_real_escape_string($conn, $_POST["name"]);
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $mobile = mysqli_real_escape_string($conn, $_POST["mobile"]);
    $id = intval($_POST["id"]);  
    if (!empty($name) && !empty($email) && !empty($mobile) && !empty($id)) {
      
        $check_sql = "SELECT * FROM icontacts WHERE email = ? OR mobile = ?";
        $check_stmt = mysqli_prepare($conn, $check_sql);
        mysqli_stmt_bind_param($check_stmt, "ss", $email, $mobile);
        mysqli_stmt_execute($check_stmt);
        $result = mysqli_stmt_get_result($check_stmt);

        if (mysqli_num_rows($result) > 0) {
            echo "Error: A contact with this email or mobile number already exists.";
        } else {
         
            $sql = "INSERT INTO icontacts (name, email, mobile, id) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            
            if ($stmt) {
               
                mysqli_stmt_bind_param($stmt, "sssi", $name, $email, $mobile, $id);
                if (mysqli_stmt_execute($stmt)) {
                    echo "Form data submitted successfully.";
                } else {
                    echo "Error: Could not execute the query. " . mysqli_error($conn);
                }
                mysqli_stmt_close($stmt);
            } else {
                echo "Error: Could not prepare the statement. " . mysqli_error($conn);
            }
        }
        mysqli_stmt_close($check_stmt);
    } else {
        echo "Error: All fields are required.";
    }
}

mysqli_close($conn);
?>
